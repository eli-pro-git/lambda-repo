import boto3

from botocore.exceptions import ClientError

client = boto3.client("s3")

def lambda_handler(event, context):
    resonse = client.list_buckets()
    for each_bucket in resonse['Buckets']:
        print(each_bucket['Name'])
    get_bucket_content(key="s3_test.json", bucketname="elitech")    


def get_bucket_content(key, bucketname):
    response = client.get_object(
        Bucket=bucketname,
        Key=key,
        )
    s3_data = response['Body'].read().decode('utf-8')  
    print(s3_data) 
   



    